// PDF Ink service worker — makes the whole app work offline.
// Your notebooks live in the browser (IndexedDB); this file keeps the app itself, its libraries and fonts available without internet.
const VERSION = 'pdfink-v14';
const SHELL = ['./', 'index.html', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'icon-180.png'];
const LIBS = [
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js',
];
const FONT_CSS = 'https://fonts.googleapis.com/css2?family=Caveat:wght@500;600&family=IBM+Plex+Sans+Thai:wght@400;500;600;700&family=Mali:wght@500&family=Sriracha&display=swap';

async function cacheUrl(cache, url) {
  try { const r = await fetch(url, { mode: 'cors', credentials: 'omit' }); if (r.ok) { await cache.put(url, r); return r; } } catch {}
  try { const r = await fetch(url, { mode: 'no-cors' }); await cache.put(url, r); return r; } catch {}
  return null;
}
async function cacheFonts(cache) {
  try {
    const r = await fetch(FONT_CSS, { mode: 'cors', credentials: 'omit' }); if (!r.ok) return;
    const css = await r.clone().text(); await cache.put(FONT_CSS, r);
    const urls = [...css.matchAll(/url\((https:\/\/fonts\.gstatic\.com\/[^)]+)\)/g)].map(m => m[1]);
    await Promise.all(urls.map(u => cacheUrl(cache, u)));
  } catch {}
}
self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(VERSION);
    await c.addAll(SHELL);
    await Promise.all(LIBS.map(u => cacheUrl(c, u)));
    await cacheFonts(c);
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== VERSION) await caches.delete(k);
    await self.clients.claim();
  })());
});
const timeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
self.addEventListener('fetch', e => {
  const req = e.request; if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/.netlify/')) return;      // AI always needs the network
  if (req.mode === 'navigate') {
    // the app page: fresh copy when the network answers quickly, otherwise the saved one (works fully offline)
    e.respondWith((async () => {
      const c = await caches.open(VERSION);
      try { const r = await timeout(fetch(req), 3500); if (r && r.ok) { c.put('index.html', r.clone()); return r; } throw 0; }
      catch { return (await c.match('index.html')) || (await c.match('./')) || new Response('<h1>ออฟไลน์</h1><p>เปิดแอปตอนต่อเน็ตอย่างน้อยหนึ่งครั้งก่อน</p>', { headers: { 'content-type': 'text/html; charset=utf-8' } }); }
    })());
    return;
  }
  // everything else (libraries, fonts, icons): cached copy first, refreshed quietly in the background
  e.respondWith((async () => {
    const c = await caches.open(VERSION), hit = await c.match(req, { ignoreVary: true });
    const net = fetch(req).then(r => { if (r && (r.ok || r.type === 'opaque')) c.put(req, r.clone()); return r; }).catch(() => null);
    if (hit) { e.waitUntil(net); return hit; }
    return (await net) || new Response('', { status: 504, statusText: 'offline' });
  })());
});
