// PDF Ink — sync across devices + share links, stored in Netlify Blobs (included free with every Netlify site).
//   /api/sync   (needs header x-app-key = APP_PASSWORD)  documents + large files (sent in 4 MB parts)
//   /api/share  POST needs the password; GET is public for whoever has the unguessable link id
// Requires APP_PASSWORD to be set in Netlify → Site configuration → Environment variables.
import { getStore } from '@netlify/blobs';

const env = k => (globalThis.Netlify ? Netlify.env.get(k) : process.env[k]) || '';
const DOC = /^data\/users\/owner(\/[A-Za-z0-9_\-~.]{1,80}){0,4}$/;
const ID = /^[A-Za-z0-9_\-]{6,64}$/;
const bad = (msg, status = 400) => new Response(msg, { status });
const store = () => getStore({ name: 'pdfink', consistency: 'strong' });

export default async (req) => {
  const url = new URL(req.url), q = url.searchParams, op = q.get('op') || '', PASS = env('APP_PASSWORD');
  const isShare = url.pathname.endsWith('/share');
  if (op === 'probe') return Response.json({ ok: true, ready: !!PASS });
  const authed = !!PASS && req.headers.get('x-app-key') === PASS;
  const st = store();

  if (isShare) {
    const id = q.get('id') || '';
    if (!ID.test(id)) return bad('bad id');
    if (req.method === 'GET') {
      const part = q.get('part');
      if (part == null) { const m = await st.get(`share/${id}/meta`, { type: 'json' }); return m ? Response.json(m) : bad('not found', 404); }
      const b = await st.get(`share/${id}/p${+part}`, { type: 'arrayBuffer' }); return b ? new Response(b, { headers: { 'content-type': 'application/octet-stream' } }) : bad('not found', 404);
    }
    if (req.method !== 'POST') return bad('method', 405);
    if (!PASS) return bad('ตั้ง APP_PASSWORD ใน Netlify ก่อนจึงจะสร้างลิงก์แชร์ได้', 403);
    if (!authed) return bad('unauthorized', 401);
    if (op === 'part') { await st.set(`share/${id}/p${+q.get('part')}`, await req.arrayBuffer()); return Response.json({ ok: true }); }
    if (op === 'done') { await st.setJSON(`share/${id}/meta`, { parts: +q.get('parts') || 1, name: (q.get('name') || '').slice(0, 200), created: Date.now() }); return Response.json({ ok: true, id }); }
    return bad('op');
  }

  if (!PASS) return bad('ตั้ง APP_PASSWORD ใน Netlify ก่อนจึงจะใช้ซิงก์ได้', 403);
  if (!authed) return bad('unauthorized', 401);

  if (op === 'list') {
    const col = q.get('col') || ''; if (!DOC.test(col)) return bad('bad path');
    const { blobs } = await st.list({ prefix: col + '/', directories: true });
    return Response.json(blobs.map(b => ({ key: b.key, etag: b.etag })));
  }
  if (op === 'getmany' && req.method === 'POST') {
    const { keys } = await req.json().catch(() => ({})); if (!Array.isArray(keys) || keys.length > 40 || !keys.every(k => DOC.test(k))) return bad('bad keys');
    const out = await Promise.all(keys.map(async key => { const r = await st.getWithMetadata(key, { type: 'json' }); return { key, etag: r ? r.etag : null, data: r ? r.data : null }; }));
    return Response.json(out);
  }
  if (op === 'get' || op === 'set' || op === 'del') {
    const doc = q.get('doc') || ''; if (!DOC.test(doc)) return bad('bad path');
    if (op === 'get') return Response.json({ data: (await st.get(doc, { type: 'json' })) ?? null });
    if (op === 'set') { const body = await req.text(); if (body.length > 4_500_000) return bad('too large', 413); await st.setJSON(doc, JSON.parse(body)); return Response.json({ ok: true }); }
    await st.delete(doc); return Response.json({ ok: true });
  }
  // large files (PDFs) in parts: apart (POST/GET), adone (POST), ainfo (GET), asset (DELETE)
  const id = q.get('id') || '';
  if (op.startsWith('a') && !ID.test(id)) return bad('bad id');
  if (op === 'apart' && req.method === 'POST') { await st.set(`asset/${id}/p${+q.get('part')}`, await req.arrayBuffer()); return Response.json({ ok: true }); }
  if (op === 'adone') { await st.setJSON(`asset/${id}/meta`, { parts: +q.get('parts') || 1, type: q.get('type') || 'application/octet-stream' }); return Response.json({ id }); }
  if (op === 'ainfo') { const m = await st.get(`asset/${id}/meta`, { type: 'json' }); return m ? Response.json(m) : bad('not found', 404); }
  if (op === 'apart') { const b = await st.get(`asset/${id}/p${+q.get('part')}`, { type: 'arrayBuffer' }); return b ? new Response(b) : bad('not found', 404); }
  if (op === 'asset' && req.method === 'DELETE') { const { blobs } = await st.list({ prefix: `asset/${id}/` }); await Promise.all(blobs.map(b => st.delete(b.key))); return Response.json({ ok: true }); }
  return bad('op');
};

export const config = { path: ['/api/sync', '/api/share'] };
