// PDF Ink — AI proxy for Netlify.
// Keeps your Claude API key on the server. The app calls POST /api/ai with {prompt, images[], tier}.
// Environment variables (Netlify → Site configuration → Environment variables):
//   ANTHROPIC_API_KEY  (required)  your key from console.anthropic.com
//   APP_PASSWORD       (recommended) a password the app asks for once, so strangers can't spend your credit
//   MODEL / MODEL_QUICK (optional)  override the models used
const env = k => (globalThis.Netlify ? Netlify.env.get(k) : process.env[k]) || '';

export default async (req) => {
  const KEY = env('ANTHROPIC_API_KEY'), PASS = env('APP_PASSWORD');
  if (req.method === 'GET') return Response.json({ ok: !!KEY, needsKey: !!PASS });
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  if (!KEY) return new Response('ANTHROPIC_API_KEY is not set on Netlify', { status: 500 });
  if (PASS && req.headers.get('x-app-key') !== PASS) return new Response('Unauthorized', { status: 401 });

  let body;
  try { body = await req.json(); } catch { return new Response('Bad JSON', { status: 400 }); }
  const { prompt, images = [], tier = 'default' } = body || {};
  if (typeof prompt !== 'string' || !prompt || prompt.length > 20000) return new Response('Bad prompt', { status: 400 });
  if (!Array.isArray(images) || images.length > 4) return new Response('Too many images', { status: 400 });
  const okType = t => ['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(t);
  let total = 0;
  for (const im of images) { if (!im || !okType(im.media_type) || typeof im.data !== 'string') return new Response('Bad image', { status: 400 }); total += im.data.length; }
  if (total > 8_000_000) return new Response('Images too large', { status: 413 });

  const model = tier === 'quick' ? (env('MODEL_QUICK') || 'claude-haiku-5-5') : (env('MODEL') || 'claude-sonnet-5-5');
  const content = [
    ...images.map(im => ({ type: 'image', source: { type: 'base64', media_type: im.media_type, data: im.data } })),
    { type: 'text', text: prompt },
  ];
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model, max_tokens: 1500, messages: [{ role: 'user', content }] }),
  });
  if (!r.ok) {
    const detail = (await r.text()).slice(0, 500);
    return new Response(detail, { status: r.status === 429 ? 429 : r.status === 401 ? 500 : 502 });
  }
  const d = await r.json();
  const text = (d.content || []).filter(c => c.type === 'text').map(c => c.text).join('');
  return Response.json({ text });
};

export const config = { path: '/api/ai' };
